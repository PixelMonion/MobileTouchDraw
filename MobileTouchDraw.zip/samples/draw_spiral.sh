input swipe 150 250 151 250 10
input swipe 151 250 152 251 10
input swipe 152 251 154 252 10
# shortened for brevity; normally generated from the script
